# Sumonflix Web App (prepared)

This repository was prepared from the zip you uploaded. It appears to be a Vite + React + TypeScript frontend project.

## What I added
- `Dockerfile` — multi-stage: builds with Node, serves `dist/` with nginx.
- `nginx.conf` — for single-page app routing.
- `.dockerignore`
- `.github/workflows/ci.yml` — simple build workflow for GitHub Actions.
- `README.md` (this file)

## How to run locally (node)
```bash
# install deps
npm ci
# dev server
npm run dev
# build
npm run build
# preview (if you have vite preview)
npm run preview
```

## Build and run with Docker
```bash
# build image
docker build -t sumonflix-app:latest .
# run container
docker run -p 8080:80 sumonflix-app:latest
# open http://localhost:8080
```

## Deploy to GitHub Pages (optional)
If you prefer GitHub Pages, adjust `package.json` `homepage` and use `gh-pages` package or GitHub Pages workflow.

---
I did not modify your source code. If you want me to:
- Fix build errors
- Add CI to deploy (Netlify/Vercel)
- Convert to full-stack with an API
Tell me which one and I will continue.